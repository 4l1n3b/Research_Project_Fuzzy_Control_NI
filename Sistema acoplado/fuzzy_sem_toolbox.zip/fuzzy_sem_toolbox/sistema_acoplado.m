%==========================================================================
% CONTROLADOR FUZZY P/ MODELO DE INCUBADORA
%==========================================================================
clear; clear all; clc; close all;

qtde_amostras = 900;
T_amost = 18;

%% ========================================================================
% INICIALIZAÇÕES
r_1t = zeros(1, qtde_amostras);
r_2u = zeros(1, qtde_amostras);

y_1t = zeros(1, qtde_amostras);
y_2u = zeros(1, qtde_amostras);
y_11t = zeros(1, qtde_amostras);
y_12u = zeros(1, qtde_amostras);
y_21t = zeros(1, qtde_amostras);
y_22u = zeros(1, qtde_amostras);
erro1 = zeros(1, qtde_amostras);
erro2 = zeros(1, qtde_amostras);
de1 = zeros(1, qtde_amostras);
de2 = zeros(1, qtde_amostras);
% tempo = zeros(1, qtde_amostras);

% Definindo as condições iniciais de 22°C e 50%
y_1t_inicial = 22; % Condição inicial da saída de temperatura
y_2u_inicial = 50; % Condição inicial da saída de umidade

% DEFININDO OS PATAMARES DE CADA ENTRADA
r_1t(1:qtde_amostras/3) = 30; 
r_1t((qtde_amostras/3+1):(2*qtde_amostras/3)) = 36; 
r_1t((2*qtde_amostras/3+1):qtde_amostras) = 36;
r_2u(1:qtde_amostras/3) = 50; 
r_2u((qtde_amostras/3+1):(2*qtde_amostras/3)) = 50;
r_2u((2*qtde_amostras/3+1):qtde_amostras) = 55;

u_1t = zeros(1, qtde_amostras);
u_2u = zeros(1, qtde_amostras);
tempo = 0:T_amost:(qtde_amostras-1)*T_amost;


% TEMPERATURE
Escala_eT = 1/18;
Escala_deT = 1/2; 
Escala_duT = 5;

% HUMIDITY
Escala_eU = 1/15;
Escala_deU= 1/2; 
Escala_duU = 6;

%% Definir funcoes de pertinencia
%Temperatura
    % Universo de discurso (local)
    u_disc = linspace(-1, 1, 100000);

    % Defining membership functions (MP)
    error_GN_T   = trapezoidal(u_disc, -1, -1, -.85, -0.7);
    error_PN_T   = triangular(u_disc, -.9, -.7, 0);
    error_zero_T  = triangular(u_disc, -.7, 0, .7);
    error_PP_T   = triangular(u_disc, 0, .7, .9);
    error_GP_T    = trapezoidal(u_disc, 0.5, .7, 1, 1);
    
    var_error_GN_T   = trapezoidal(u_disc, -1, -1, -.9, -0.5);
    var_error_PN_T   = triangular(u_disc, -1, -.5, 0);
    var_error_zero_T  = triangular(u_disc, -.5, 0, .5);
    var_error_PP_T   = triangular(u_disc, 0, .5, 1);
    var_error_GP_T    = trapezoidal(u_disc, 0.5, .9, 1, 1);

    % Singletons de saida
    vGPT   = 1; vPPT = .2; vZT = 0; vPNT = -.5; vGNT = -1;
% ----------------------------------------------------
% 7. PLOTAGEM DOS RESULTADOS
% ----------------------------------------------------
% Gráficos
    figure(1);
    subplot(1,3,1)
    plot(u_disc, error_GN_T, u_disc, error_PN_T, u_disc, error_zero_T, u_disc, error_PP_T,u_disc, error_GP_T, 'LineWidth', 3);
    legend('GN', 'PN', 'Z', 'PP', 'GP');
    title('Entrada: Erro');
    xlabel('Erro');
        ylabel('Grau de Pertinência (\mu)');

    axis([-1 1 0 1]);
    grid on;

    subplot(1,3,2)
    plot(u_disc, var_error_GN_T, u_disc, var_error_PN_T, u_disc, var_error_zero_T, u_disc, var_error_PP_T,u_disc, var_error_GP_T, 'LineWidth', 3);
    legend('GN', 'PN', 'Z', 'PP', 'GP');
    title('Entrada: Variaçao do Erro');
    xlabel('Variaçao do Erro');
        ylabel('Grau de Pertinência (\mu)');

    axis([-1 1 0 1]);
    grid on;

 subplot(1,3,3)
    x_coord = [vGNT, vPNT, vZT, vPPT, vGPT];
    y_coord = [1, 1, 1, 1, 1]; 
    labels = {'GN', 'PN', 'zero', 'PP', 'GP'};
    
    % Definindo cores menos saturadas (RGB)
    % [Vermelho suave, Laranja, Amarelo/Dourado, Roxo suave, Verde oliva]
    cores = {
        [0.85, 0.33, 0.31], ... % GN (Suave)
        [0.93, 0.69, 0.39], ... % PN (Suave)
        [0.93, 0.84, 0.39], ... % zero (Dourado)
        [0.64, 0.45, 0.68], ... % PP (Roxo)
        [0.47, 0.67, 0.35]      % GP (Verde)
    };

    hold on;
    for i = 1:length(x_coord)
        % Plota o stem com as novas cores
        h = stem(x_coord(i), y_coord(i), 'LineWidth', 3, ...
            'MarkerFaceColor', cores{i}, 'Color', cores{i}, ...
            'Marker', 'o', 'MarkerSize', 6);
        
        % Adiciona o rótulo
        text(x_coord(i), 1.05, labels{i}, ...
            'HorizontalAlignment', 'center', ...
            'FontWeight', 'bold', ...
            'Color', cores{i}, ...
            'FontSize', 10);
    end
    hold off;

    % Ajustes de Eixo
    set(gca, 'XTick', x_coord);
    set(gca, 'XTickLabel', x_coord); 
    
    title('Saída: Variação do Sinal de Controle');
    xlabel('Valor do Singleton');
    ylabel('Grau de Pertinência (\mu)');
    axis([-1.5 2 0 1.25]); 
    grid on;
%Umidade
    % Universo de discurso (local para a função)
    % u_disc = linspace(-1, 1, 10000);

    % Defining membership functions (MP)
    error_GN_U   = trapezoidal(u_disc, -1, -1, -.85, -0.7);
    error_PN_U   = triangular(u_disc, -.9, -.7, 0);
    error_zero_U  = triangular(u_disc, -.6, 0, .5);
    error_PP_U   = triangular(u_disc, 0, .5, .9);
    error_GP_U    = trapezoidal(u_disc, 0.5, .85, 1, 1);
    
    var_error_GN_U   = trapezoidal(u_disc, -1, -1, -.7, -0.5);
    var_error_PN_U   = triangular(u_disc, -1, -.5, 0);
    var_error_zero_U  = triangular(u_disc, -.5, 0, .4);
    var_error_PP_U   = triangular(u_disc, 0, .5, 1);
    var_error_GP_U    = trapezoidal(u_disc, 0.5, .7, 1, 1);

    % Singletons de saida
    vGPU = .9; vPPU = .2; vZU = 0; vPNU = -.5; vGNU = -1;
% Gráficos
    figure(2);
    subplot(1,3,1)
    plot(u_disc, error_GN_U, u_disc, error_PN_U, u_disc, error_zero_U, u_disc, error_PP_U,u_disc, error_GP_U, 'LineWidth', 3);
    legend('GN', 'PN', 'Z', 'PP', 'GP');
    title('Entrada: Erro');
    xlabel('Erro');
        ylabel('Grau de Pertinência (\mu)');

    axis([-1 1 0 1]);
    grid on;
subplot(1,3,2)
    plot(u_disc, var_error_GN_U, u_disc, var_error_PN_U, u_disc, var_error_zero_U, u_disc, var_error_PP_U,u_disc, var_error_GP_U, 'LineWidth', 3);
    legend('GN', 'PN', 'Z', 'PP', 'GP');
    title('Entrada: Variaçao do Erro');
    xlabel('Variaçao do Erro');
        ylabel('Grau de Pertinência (\mu)');

    axis([-1 1 0 1]);
    grid on;

    % --- Gráfico de Saída (Singletons) ---
subplot(1,3,3)
    x_coord = [vGNU, vPNU, vZU, vPPU, vGPU];
    y_coord = [1, 1, 1, 1, 1]; 
    labels = {'GN', 'PN', 'Z', 'PP', 'GP'};
    
    % Definindo cores menos saturadas (RGB)
    % [Vermelho suave, Laranja, Amarelo/Dourado, Roxo suave, Verde oliva]
    cores = {
        [0.85, 0.33, 0.31], ... % GN (Suave)
        [0.93, 0.69, 0.39], ... % PN (Suave)
        [0.93, 0.84, 0.39], ... % zero (Dourado)
        [0.64, 0.45, 0.68], ... % PP (Roxo)
        [0.47, 0.67, 0.35]      % GP (Verde)
    };

    hold on;
    for i = 1:length(x_coord)
        % Plota o stem com as novas cores
        h = stem(x_coord(i), y_coord(i), 'LineWidth', 3, ...
            'MarkerFaceColor', cores{i}, 'Color', cores{i}, ...
            'Marker', 'o', 'MarkerSize', 6);
        
        % Adiciona o rótulo
        text(x_coord(i), 1.05, labels{i}, ...
            'HorizontalAlignment', 'center', ...
            'FontWeight', 'bold', ...
            'Color', cores{i}, ...
            'FontSize', 10);
    end
    hold off;

    % Ajustes de Eixo
    set(gca, 'XTick', x_coord);
    set(gca, 'XTickLabel', x_coord); 
    
    title('Saída: Variação do Sinal de Controle');
    xlabel('Valor do Singleton');
    ylabel('Grau de Pertinência (\mu)');
    axis([-1.5 2 0 1.25]); 
    grid on;
%% ========================================================================

for k = 1:7 
    y_1t(k) = y_1t_inicial;
    y_2u(k) = y_2u_inicial;
    erro1(k) = r_1t(k) - y_1t(k);
    erro1_norm(k) = erro1(k)*Escala_eT;
    erro2(k) = r_2u(k) - y_2u(k);
    erro2_norm(k) = erro2(k)*Escala_eU;
    tempo(k) = (k) * T_amost;
end


% Load do arquivo .fis
% try
%     fuzzy1 = readfis('fuzzy_IN1_temperatura.fis');
% catch ME
%     error('Arquivo FIS não encontrado.');
% end
% try
%     fuzzy2 = readfis('fuzzy_IN2_umidade.fis');
% catch ME
%     error('Arquivo FIS não encontrado.');
% end

% SCALE FACTORS OF THE VARIABLES


%% LOOP DE CONTROLE

for k = 8:qtde_amostras
    y_11t(k) = 0.9678 * y_11t(k-1) + 0.08796 * u_1t(k-4) + 0.00509 * u_1t(k-5);
    y_12u(k) = 0.9331 * y_12u(k-1) - 0.003556 * u_2u(k-3) - 0.01718 * u_2u(k-4);
    
    y_21t(k) = 0.9676 * y_21t(k-1) - 0.1294 * u_1t(k-6) - 0.007485 * u_1t(k-7);
    y_22u(k) = 0.9048 * y_22u(k-1) + 0.02455 * u_2u(k-1) + 0.1869 * u_2u(k-2);
    
    % Saída do Sistema
    y_1t(k) = y_11t(k) + y_12u(k) + y_1t_inicial;
    y_2u(k) = y_21t(k) + y_22u(k) + y_2u_inicial;
    
    % Cálculo do erro 
    erro1(k) = r_1t(k) - y_1t(k);
    erro2(k) = r_2u(k) - y_2u(k);
    e1_fuzzy = erro1(k)*Escala_eT;
    e2_fuzzy = erro2(k)*Escala_eU;

    % Variação do Erro 
    de1(k) = erro1(k) - erro1(k-1); 
    de1_fuzzy = de1(k)*Escala_deT;
    de2(k) = erro2(k) - erro2(k-1); 
    de2_fuzzy = de2(k)*Escala_deU;
    %sinal de controle
    % Fuzzificação
    s1 = singleton(u_disc, error_GN_T, e1_fuzzy);
    s2 = singleton(u_disc, error_PN_T, e1_fuzzy);
    s3 = singleton(u_disc, error_zero_T, e1_fuzzy);
    s4 = singleton(u_disc, error_PP_T, e1_fuzzy);
    s5 = singleton(u_disc, error_GP_T, e1_fuzzy);
    
    s6 = singleton(u_disc, var_error_GN_T, de1_fuzzy);
    s7 = singleton(u_disc, var_error_PN_T, de1_fuzzy);
    s8 = singleton(u_disc, var_error_zero_T, de1_fuzzy);
    s9 = singleton(u_disc, var_error_PP_T, de1_fuzzy); 
    s10 = singleton(u_disc, var_error_GP_T, de1_fuzzy); 
    
    % Regras
    r1 = min(s1, s6); r2 = min(s1, s7); r3 = min(s1, s8); r4 = min(s1, s9); r5 = min(s1, s10);
    r6 = min(s2, s6); r7 = min(s2, s7); r8 = min(s2, s8); r9 = min(s2, s9); r10 = min(s2, s10);
    r11 = min(s3, s6); r12 = min(s3, s7); r13 = min(s3, s8); r14 = min(s3, s9); r15 = min(s3, s10);
    r16 = min(s4, s6); r17 = min(s4, s7); r18 = min(s4, s8); r19 = min(s4, s9); r20 = min(s4, s10);
    r21 = min(s5, s6); r22 = min(s5, s7); r23 = min(s5, s8); r24 = min(s5, s9); r25 = min(s5, s10);
    
    % Implicação
    out1 = r1 * vGNT; out2 = r2 * vPNT; out3 = r3 * vPNT; out4 = r4 * vPNT; out5 = r5 * vPPT;
    out6 = r6 * vGNT; out7 = r7 * vPNT; out8 = r8 * vPNT; out9 = r9 * vZT; out10 = r10 * vGPT;
    out11 = r11 * vPNT; out12 = r12 * vPNT; out13 = r13 * vZT; out14 = r14 * vPPT; out15 = r15 * vGNT;
    out16 = r16 * vPNT; out17 = r17 * vZT; out18 = r18 * vGPT; out19 = r19 * vGPT; out20 = r20 * vGPT;
    out21 = r21 * vPPT; out22 = r22 * vGPT; out23 = r23 * vGPT; out24 = r24 * vGPT; out25 = r25 * vGPT;

    % Agregação e Média Ponderada
    sum_weight = (r1+r2+r3+r4+r5+r6+r7+r8+r9+r10+r11+r12+r13+r14+r15+r16+r17+r18+r19+r20+r21+r22+r23+r24+r25);
    if sum_weight > 0
        sum_out = (out1+out2+out3+out4+out5+out6+out7+out8+out9+out10+out11+out12+out13+out14+out15+out16+out17+out18+out19+out20+out21+out22+out23+out24+out25);
        du_out = sum_out/ sum_weight;
    else
        du_out = 0;
    end

    % ================================================
    
    du1(k) = Escala_duT*du_out;
  
    u_1t(k) = u_1t(k-1) + du1(k);
   

    if u_1t(k) > 100
        u_1t(k) = 100;
    elseif u_1t(k) < 0
        u_1t(k) = 0;
    end
    % Fuzzificação
    s1 = singleton(u_disc, error_GN_U, e2_fuzzy);
    s2 = singleton(u_disc, error_PN_U, e2_fuzzy);
    s3 = singleton(u_disc, error_zero_U, e2_fuzzy);
    s4 = singleton(u_disc, error_PP_U, e2_fuzzy);
    s5 = singleton(u_disc, error_GP_U, e2_fuzzy);
    
    s6 = singleton(u_disc, var_error_GN_U, de2_fuzzy);
    s7 = singleton(u_disc, var_error_PN_U, de2_fuzzy);
    s8 = singleton(u_disc, var_error_zero_U, de2_fuzzy);
    s9 = singleton(u_disc, var_error_PP_U, de2_fuzzy); 
    s10 = singleton(u_disc, var_error_GP_U, de2_fuzzy); 

    % Regras e Implicação (Mamdani/Singleton)
    r1U = min(s1, s6);  out1_U = r1U * vGNU;
    r2U = min(s1, s7);  out2_U = r2U * vPNU;
    r3U = min(s1, s8);  out3_U = r3U * vPNU;
    r4U = min(s1, s9);  out4_U = r4U * vPNU;
    r5U = min(s1, s10); out5_U = r5U * vPPU;
    
    r6U = min(s2, s6);  out6_U = r6U * vGNU;
    r7U = min(s2, s7);  out7_U = r7U * vPNU;
    r8U = min(s2, s8);  out8_U = r8U * vPNU;
    r9U = min(s2, s9);  out9_U = r9U * vZU;
    r10U = min(s2, s10); out10_U = r10U * vGPU;
    
    r11U = min(s3, s6);  out11_U = r11U * vPNU;
    r12U = min(s3, s7);  out12_U = r12U * vPNU;
    r13U = min(s3, s8);  out13_U = r13U * vZU;
    r14U = min(s3, s9);  out14_U = r14U * vPPU;
    r15U = min(s3, s10); out15_U = r15U * vGNU;
    
    r16U = min(s4, s6);  out16_U = r16U * vPNU;
    r17U = min(s4, s7);  out17_U = r17U * vZU;
    r18U = min(s4, s8);  out18_U = r18U * vGPU;
    r19U = min(s4, s9);  out19_U = r19U * vGPU;
    r20U = min(s4, s10); out20_U = r20U * vGPU;
    
    r21U = min(s5, s6);  out21_U = r21U * vZU;
    r22U = min(s5, s7);  out22_U = r22U * vPPU;
    r23U = min(s5, s8);  out23_U = r23U * vGPU;
    r24U = min(s5, s9);  out24_U = r24U * vGPU;
    r25U = min(s5, s10); out25_U = r25U * vGPU;

    % Agregação e Defuzzificação (Média Ponderada)
    sum_weightU = (r1U+r2U+r3U+r4U+r5U+r6U+r7U+r8U+r9U+r10U+r11U+r12U+r13U+r14U+r15U+r16U+r17U+r18U+r19U+r20U+r21U+r22U+r23U+r24U+r25U);
    
    if sum_weightU > 0
        sum_outU = (out1_U+out2_U+out3_U+out4_U+out5_U+out6_U+out7_U+out8_U+out9_U+out10_U+out11_U+out12_U+out13_U+out14_U+out15_U+out16_U+out17_U+out18_U+out19_U+out20_U+out21_U+out22_U+out23_U+out24_U+out25_U);
        du_outU = sum_outU/ sum_weightU;
    else
        du_outU = 0;
    end
    du2(k) = Escala_duU*du_outU;
    u_2u(k) = u_2u(k-1) + du2(k);
   if u_2u(k) > 100
        u_2u(k) = 100;
    elseif u_2u(k) < 0
        u_2u(k) = 0;
    end
end
  
 

% ----------------------------------------------------
% 7. PLOTAGEM DOS RESULTADOS
% ----------------------------------------------------
clf(figure(4))
figure(4);
% temperatura
subplot(4, 2, 1);
plot(tempo/60, r_1t, 'r--', 'LineWidth', 1.5);
hold on;
plot(tempo/60, y_1t, 'b', 'LineWidth', 2);
title('Saída de Temperatura');
xlabel('Tempo (min)');
ylabel('Temperatura (°C)');
legend('Referência', 'Saída');
grid on;
subplot(4, 2, 3);
plot(tempo/60, u_1t, 'g', 'LineWidth', 2);
title('Sinal de Controle (u)');
xlabel('Tempo (min)');
ylabel('Temperatura (°C)');
grid on;

subplot(4, 2, 5);
plot(tempo/60, erro1,'b', 'LineWidth', 1.5);
title('Erro (e)');
xlabel('Tempo (min)');
ylabel('Temperatura (°C)');
grid on;
subplot(4, 2, 7);
plot(tempo/60, de1,'r', 'LineWidth', 1.5);
title('Variação do Erro (de)');
xlabel('Tempo (min)');
ylabel('Temperatura (°C)');
grid on;
% umidade
subplot(4, 2, 2);
plot(tempo/60, r_2u, 'r--', 'LineWidth', 1.5);
hold on;
plot(tempo/60, y_2u, 'b', 'LineWidth', 2);
title('Saída de Umidade');
xlabel('Tempo (min)');
ylabel('Umidade Relativa (%)');
legend('Referência', 'Saída');
grid on;
subplot(4, 2, 4);
plot(tempo/60, u_2u, 'g', 'LineWidth', 2);
title('Sinal de Controle (u)');
xlabel('Tempo (min)');
ylabel('Umidade Relativa (%)');
grid on;

subplot(4, 2, 6);
plot(tempo/60, erro2,'b', 'LineWidth', 1.5);
title('Erro (e)');
xlabel('Tempo (min)');
ylabel('Umidade Relativa (%)');
grid on;
subplot(4, 2, 8);
plot(tempo/60, de2,'r', 'LineWidth', 1.5);
title('Variação do Erro (de)');
xlabel('Tempo (min)');
ylabel('Umidade Relativa (%)');
grid on;

% ==== SALVAR DADOS EM PLANILHA ====
T = table(tempo(:), r_1t(:), r_2u(:), y_1t(:), y_2u(:), u_1t(:), u_2u(:), erro1(:), erro2(:), ...
    'VariableNames', {'Tempo','Referencia_Temperatura', 'Referencia_Umidade','Saida_Temperatura', 'Saida_Umidade', 'Sinal_Controle_Temperatura', 'Sinal_Controle_Umidade','Erro_Temperatura', 'Erro_Umidade'});

filename = 'planilhas/dados_FLC_TITO_patamares.csv';
writetable(T, filename);
disp(['Dados salvos em: ' filename]);

% ==== LER DADOS DA PLANILHA ====
% T_lida = readtable(filename);
% 
% disp('Primeiras linhas dos dados lidos:');
% disp(head(T_lida));
% % 
% % Se quiser usar as variáveis separadas:
% Tempo = T_lida.Tempo;
% r_1t = T_lida.Referencia_Temperatura;
% y_1t = T_lida.Saida_Temperatura;
% u_1t = T_lida.Sinal_Controle_Temperatura;
% erro1 = T_lida.Erro_Temperatura;
% r_2u= T_lida.Referencia_Umidade;
% y_2u = T_lida.Saida_Umidade;
% u_2u = T_lida.Sinal_Controle_Umidade;
% erro2 = T_lida.Erro_Umidade;
